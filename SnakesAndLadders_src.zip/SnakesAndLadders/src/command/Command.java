package command;
import components.Player;

public interface Command {
	
	void execute(Player p);
}
