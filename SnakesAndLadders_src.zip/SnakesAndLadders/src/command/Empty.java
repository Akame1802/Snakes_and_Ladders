package command;

import components.Player;

public class Empty implements Command {
	
	public void execute(Player p) { }
}
