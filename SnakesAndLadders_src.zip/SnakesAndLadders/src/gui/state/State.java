package gui.state;

public interface State {
	
	void handle();
}
